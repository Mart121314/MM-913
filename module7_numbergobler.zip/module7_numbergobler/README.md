Koden er godt strukturert, og hver funksjon har sin egen jobb. Det gjør det lettere å forstå hva som gjør hva og viss noe skal bli endret.
Koden funker fint og gjør det den skal, er litt usikker på om update funksjonen fungerer helt mtp at spillet skal slutte når man ikke har fler lovlig valg
når spillet er slutt så vises den siste tasten man trykte, dette kunne jeg fjernet men visste ikke helt hvordan.
