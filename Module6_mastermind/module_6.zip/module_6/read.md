1 splashscreen ser ut til å virke men har samme bug som nr2. Hvor den blir printet to ganger.
2 bug med spørsmål om hvor mange attempts man vil ha, der du blir spurt 2 ganger når spillet starter opp.
3 Ser ut til å virke fint. man får tilbakemelding når man gjør en sekvens lengre/mindre.
4 ble bugget når man skulle colorize tilbakemeldingen fra spillet så er usikker på om den faktisk virker som den skal.
5 lagde store problemer i koden, uten den så funker spillet fint når det kommer til tilbakemeldingen, problemet er bare at spillet så stygt ut når man spilte.
6 var litt usikker på "legend" men tror jeg har gjort det riktig.
7 denne funker veldig bra man skriver inn farger istedenfor tall
8 denne funker fint
9 problemet med funksjonen når man starter spillet på nytt er at den printer ut to ganger i starten av spillet, den printer 2 ganger spørsmålet om hvor mange forsøk man vil ha og 2 ganger splashscreen.
