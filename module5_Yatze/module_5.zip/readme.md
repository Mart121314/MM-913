The code functions mostly, there are some small errors which is when the score is being printed it shows -1 pr rule that hasn't been used yet,
and it's heavily reliant on side-effects to work.
Full house is also not working yet, I had some issues with it and I've tried 20 different ways to make it work.
I'm satisfied with everything else working though, it's been painful to work with. I could've refactored the code if I had more time.
