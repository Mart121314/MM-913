styrker og svakheter i koden

koden er lett å jobbe med, den har en enkel struktur. Og funksjoner som gjør veldig mye av jobben.

problemer med koden er at den ikke vil si hvem som vinner eller tape -> se linje 84-93
jeg har også hatt problemer med å endre fargen på selve teksten i language.mjs noe jeg tenker hadde vært gøyt å gjøre.