// Common setup 
const id = "hallway";
const description = "You are inn a hallway, to the left there is utter darkness, to the right there is flickering lights and a monster coming towards you";

// Creating "Things for the room " ----------------------------------------------------------------

const monster = {
    status: "Live",
    hp: 200,
    kick:{
        statusLive:"The monster grunts",
        effect: (subject, playerInput) => { 
            
        }
    }
}



// Exporting the location (the structure is important)

export default { 
    id,
    description,
    subjects:{
        
    }
}