//#region 
import * as readlinePromises from 'node:readline/promises';
import fs from "node:fs"
const rl = readlinePromises.createInterface({input: process.stdin,output: process.stdout});
//#endregion

// Henter grafikken vi skal tegne.
import { HANGMAN_UI } from './graphics.mjs';

const RESET = '\x1b[0m';
const GREEN = '\x1b[32m';
const RED = '\x1b[31m';
const YELLOW = '\x1b[33m';
const BLUE = '\x1b[34m';

// Slik at vi skal slippe å skrive console.log
const log = console.log;

// Alle ord som er med i spillet.
const ALLE_ORD = fs.readFileSync("./ord.txt","utf-8").split("\n");

// Trekke ord for spillet 
const ord = trekkTilfeldigOrdFraListe(ALLE_ORD).toLowerCase();
const ordElementer = ord.split("");

// Lage grafikk som viser antall bokstaver i ordet?
const status = lagOrdVisningFraOrd(ord);

// Hva har spilleren tippet som er feil?
let feil = [];

let isPlaying = true;

while(isPlaying){

    // Vis spilleren hva som har skjedd så langt.
    ShowStatus()

    // Velge en bokstav
    const valgtBokstav = (await rl.question("Velge en bokstav ")).toLowerCase();

    // Sjekk valget mot lista?
    if(ord.includes(valgtBokstav)){
        for(let i = 0; i < ord.length; i++){
            if(ordElementer[i] === valgtBokstav){
                status[i] = `${GREEN}${valgtBokstav}${RESET}`;
            }
        }
    } else{
        feil.push(valgtBokstav);
    }

    console.clear();

    if(feil.length === HANGMAN_UI.length){
        log("GAME OVER");
        isPlaying = false;
    }

}

function ShowStatus(){
    log("HANGMAN");
    if(feil.length > 0){
        log(HANGMAN_UI[feil.length-1]);
    }
    let summering = status.join(" ");
    log(summering);
    let alleFeilValg = feil.join(",");
    log(`Feil bokstaver du har tippet:${RED} ${alleFeilValg} ${RESET}`);
}


function lagOrdVisningFraOrd(ord){
    return new Array(ord.length).fill("_");
}

function trekkTilfeldigOrdFraListe(liste){
    const index = Math.floor(Math.random() * liste.length-1)+1;
    return liste[index];
}