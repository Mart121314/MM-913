//#region
import * as readlinePromises from "node:readline/promises";
const rl = readlinePromises.createInterface({
  input: process.stdin,
  output: process.stdout
});
//#endregion

// Importing locations  
import start from "./locationStart.mjs";
import hallway from "./locationHallway.mjs";
import {SPLASH_SCREEN } from "./splashscreen.mjs";
import University from "./The University.mjs";
import principleOffice from "./principleOffice.mjs";
import home from "./home.mjs";

const game_locations = [
    start,
    hallway,
    University,
    principleOffice,
    home
];





const COMMANDS = [
    "q",
    "kick",
    "talk",
    "take",
    "use",
    "go",
    "help",
    "inventory",
    "description",
    "attack"
]

let feedbackToPlayer;

let playerCommand;

let player = {
    hitcount : 2,
    inventory:[],
}

let currentLocation = game_locations[0]; 

let isPlaying = true; 

async function updateGame(){
    feedbackToPlayer = currentLocation.description;
    if(playerCommand){
        const target = currentLocation.subjects[playerCommand.subject];
        if(target && target[playerCommand.command]){ 
            const statusId = `status${target?.status}`
            feedbackToPlayer = target[playerCommand.command][statusId];
            target[playerCommand.command].effect(target,playerCommand,currentLocation,player,changeLocation);
        } 
        else if (target && target.default) { 
            feedbackToPlayer = `${playerCommand.raw}. Does nothing\n${target.default.description}`;
            if(target.default.effect){
                target.default.effect(target,playerCommand,currentLocation,player,changeLocation);
            }
        }
        else {
            feedbackToPlayer = `${playerCommand.raw}. Does nothing`;
        }
    }
    log(feedbackToPlayer);
    
    playerCommand = await takeCommandFromUser();
    return playerCommand.command != "q";
}

async function takeCommandFromUser(){
    let playerInput = await rl.question("> ");
    playerInput = cleanUserInput(playerInput);
    let command = extractCommand(playerInput);
    let subject = extractSubject(playerInput, Object.keys(currentLocation.subjects));
    
    if (command === "help"){
        help();
    }
    if (command === "inventory"){
        myInventory();
    }

    return {command, subject, raw:playerInput};
}

function extractSubject(userInput, possibleTargets){
    let output = undefined;
    const sentance = userInput.split(" ");

    for(let word of sentance){
        for(let target of possibleTargets){
            if(word === target){
                output =  target;
                break;
            }
        }
    }

    return output;
}

function myInventory(){
    for (let i = 0; i < player.inventory.length; i++){
       log(player.inventory[i])
    }
   }

function help() {
    log("The available commands are:");
    for (let command of COMMANDS) {
        log(command);
    }
}

function extractCommand(userInput){
    let output = undefined;
    const sentance = userInput.split(" ");

    for(let word of sentance){
        for(let command of COMMANDS){
            if(word === command){
                output =  command;
                break;
            }
        }
    }

    return output;
}

function findLocation(locationID){
    return game_locations.find((location) => { return location.id === locationID})
}

function cleanUserInput(sourceInput){
    return sourceInput.trim().toLowerCase();
}

function changeLocation(locationID) {
    const newLocation = findLocation(locationID);
    if(newLocation){
        currentLocation = newLocation;
        feedbackToPlayer = `${feedbackToPlayer}\n${currentLocation.description}` ;
    } else{
        console.error("Error: no location with id " + locationID);
    }
}

log(SPLASH_SCREEN.join(""));

while(isPlaying){
    isPlaying = await updateGame();
}

process.exit();

function log(tekst, isError) {
    if (!isError) {
        console.log(tekst);
    } else {
        console.error(tekst);
    }
}


