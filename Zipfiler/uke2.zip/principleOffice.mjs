
const id = "principleOffice";
const description = "You are in the principle's office, there's the principle you have to defeat the principle to finally get your grades.";

const principle = {
    status: "Immortal",
    hassword: "false",

    kick: {
        effect: (subject, playerInput, location, player, changeLocation) => {
            if (player.hassword == "true") {
                subject.status = "killable"
                console.log(subject.status)
            }
            else {
                subject.status = "Immortal"
                console.log(subject.status)
            }
        }
    },

    attack: {
        effect: (subject, playerInput, location, player, changeLocation) => {
            if (subject.status === "killable") {
                principle.status = "Idle";
                principle.attackCount = 0;
                principle.attack = {};
                principle.attack.statusIdle = "The sword you're wielding seem to be very effective, keep going!";
                principle.attack.statusProvoked = "The principle has been weakend!";
                principle.attack.statusDead = "You've slain the evil principle, congratulations! Now you've got to take your grades.";
                principle.attack.effect = (target, playerInput, location, player, changeLocation) => {
                    target.attackCount += 1;
                    target.status = "Provoked"
                    if (target.attackCount >= 3) {
                        target.status = "Dead";
                        player.hitPoints -= 1;
                    } else {
                    }
                }
            } else {
                if (subject.status === "Immortal") {
                    principle.status = "Idle";
                    principle.attackCount = 0;
                    principle.attack = {};
                    principle.attack.statusIdle = "The principle is very strong, maybe try something else?";
                    principle.attack.statusProvoked = "Yeah I think you've got to keep attacking....";
                    principle.attack.statusDead = "You've slain the evil principle, congratulations! Now you've got to take your grades.";
                    principle.attack.effect = (target, playerInput, location, player, changeLocation) => {
                        target.attackCount += 1;
                        target.status = "Provoked"
                        if (target.attackCount >= 5) {
                            target.status = "Dead";
                            player.hitPoints -= 1;
                        }
                    }
                }
            }
        }
    }
}




const portalhome = {
    status:"Closed",
    hasgrades: "false", 
    kick:{
        effect: (subject, playerInput, location,player,changeLocation) => {  
            if(player.hasgrades == "true")
            { subject.status = "Open"
            console.log(subject.status)}
           else
            { subject.status = "Closed"
            console.log("You seem to be missing the grades, pick up your grades!")}
        }
         },
    go:{
        statusClosed:"You don't have your grades, take your grades!",
        statusOpen:"You leave the principle office and return home through the portal",
        effect:  (subject, playerInput, location,player,changeLocation) => { 
            if(subject.status === "Open"){
                changeLocation("home");
            }
        }
    }

}

const grades = {
    id:"grades",
    description:"You scored full points on your grades, great job!",
    worksWith:"portaltohome",
    status:"OnFloor",
    hasgrades: false,
    take:{
        statusOnFloor:"You pick up the grades and put it in your pocket. Time to use the portalhome",
        statusPocket:"You have allready taken the grades",
        effect: (subject, playerInput, location,player,changeLocation) => { 
            player.hasgrades = "true";
            subject.status = "Pocket"
            player.inventory.push({id:subject.id, description:subject.description, worksWith:subject.worksWith})
            
        }
    }
}


export default {
    id,
    description,
    subjects: {
        principle,
        grades,
        portalhome
    }
}
