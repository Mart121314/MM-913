styrker og svakheter i koden

noen svakheter med koden er at mye som blir gjort omigjen i koden slik som dører kunne vært gjort om til funksjoner slik at jeg slipper å gjøre så mye arbeid.
man får også "undefined" som tilbakemelding når man sparker opp dører.


koden funker fint og gjør det som er forventet skal bli gjort. Selv om koden er lang så er den ikke så veldig vanskelig å forstå seg på. btw det er meningen at man ikke vinner over javascript monsteret. buggen er dermed at viss en spiller burker nok tid så får han drept javascript monsteret.