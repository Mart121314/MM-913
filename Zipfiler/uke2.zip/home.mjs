
const id = "home";
const description = "You finally got home with your perfect grades, you open up discord to find out that you still have more coding work that you need to do. You need to defeat the great javascriptmonster";


const javascriptmonster = {}
javascriptmonster.status = "Idle";
javascriptmonster.kickCount = 0;
javascriptmonster.kick = {};
javascriptmonster.kick.statusIdle = "The javascriptmonster says: python coding language sucks ";
javascriptmonster.kick.statusProvoked = "you seem to have provoked the javascriptmonster, think fast...";
javascriptmonster.kick.statusDead = "The javascriptmonster died, and you can finally relax again";
javascriptmonster.kick.effect = (target, playerInput, location,player,changeLocation) => {
    target.kickCount += 1;
    target.status = "Provoked"
    if(target.kickCount >= 67568){
        target.status = "Dead";
        player.hitPoints -= 1;
    }
}



export default {
    id,
    description,
    subjects: {
        javascriptmonster
    }
}
