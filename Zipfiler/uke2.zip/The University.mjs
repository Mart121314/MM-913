const id = "University";
const description = "The passion for adventure often leads us onto the path of perils and hazards, and a few student members have bitten off a little more than they could chew... You finally arrive at the University and you have been tasked as an ambassador to help the students seek more allies. You approach some teachers";


const teachers = {}
teachers.status = "Idle";
teachers.talkCount = 0;
teachers.talk = {};
teachers.talk.statusIdle = "Getting spoken to makes them very very angry";
teachers.talk.statusAngry = "Yeah you better run.";
teachers.talk.statusEnraged = "They charge after you! and you find the Sword of a thousand truths. Do you wish to pick this up?";
teachers.talk.effect = (target, playerInput, location,player,changeLocation) => {
    target.talkCount += 1;
    target.status = "Angry"
    if(target.talkCount >= 3){
        target.status = "Enraged";
        player.hitPoints -= 1;
    }
}

const sword = {
    id:"Sword",
    description:"",
    worksWith:"Principle",
    status:"OnFloor",
    hassword: false,
    take:{
        statusOnFloor:"You pick up the sword and put it in your pocket, and then you head over to the officedoor.",
        statusPocket:"You have already taken the sword",
        effect: (subject, playerInput, location,player,changeLocation) => { 
            player.hassword = "true";
            subject.status = "Pocket"
            player.inventory.push({id:subject.id, description:subject.description, worksWith:subject.worksWith})
            
        }
    }
}

const officedoor = {
    status:"Closed",
    kick:{
        statusClosed:"The door is of impeccable quality, but you've grown strong and the office door splinters as your foot impacts it.",
        statusOpen:"The office door is open, trying to kick it made you fall on your face.",
        effect: (subject, playerInput, location,player,changeLocation) => { subject.status = "Open"}
    },
    go:{
        statusClosed:"You try going through the door, but it is closed so you bump your head.",
        statusOpen:"You leave the room",
        effect:  (subject, playerInput, location,player,changeLocation) => { 
            if(subject.status === "Open"){
                changeLocation("principleOffice");
            }
        }
    }

}

const doorback = {
    status:"Open",
    kick:{
        statusOpen:"The door is open, trying to kick it made you fall on your face.",
        effect: (subject, playerInput, location,player,changeLocation) => { subject.status = "Open"}
    },
    go:{
        statusOpen:"You leave the room",
        effect:  (subject, playerInput, location,player,changeLocation) => { 
            if(subject.status === "Open"){
                changeLocation("start");
            }
        }
    }

}

export default { 
    id,
    description,
    subjects:{
        sword,
        teachers,
        officedoor,
        doorback
    }
}