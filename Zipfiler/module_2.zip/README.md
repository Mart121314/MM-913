Strengths and weaknesses in my code


Koden min har en grei struktur. Det er lett å endre på språket og gjøre andre justeringer med det.  Det er også mulig å endre på evalueringen og utvide.

det som er problematisk med koden er at den kjører i en loop og man blir aldri spurt om man vil avslutte spillet. Det som også er problematisk med koden er at den har kode som ikke blir brukt i linje 3 og 16. 

Viss det er noe jeg ville endret på så er det å sette hele spillet i en funksjon istedenfor. Det hadde gjort det lettere å lese koden.