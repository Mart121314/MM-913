# Assignment
Before you write any code, you should "sketch" the pseudo code and make a flowchart for how you plan to do the following alterations to the game.

- Make it so the player can play multiple rounds without exiting the process. 
- Make it so that when the player exits, they are shown a statistical summary. Include things like the number of plays, average numbers of guesses, the total number of guesses etc.
- Offer the player a choice between English and a second language. The game should only interact with the player in the chosen language when. 